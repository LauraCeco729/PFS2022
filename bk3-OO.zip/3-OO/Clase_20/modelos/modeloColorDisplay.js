"use strict";
exports.__esModule = true;
var ColorDisplay = /** @class */ (function () {
    function ColorDisplay() {
    }
    ColorDisplay.prototype.setColorDisplay = function (color) {
        this.colorDisplay = color;
    };
    ColorDisplay.prototype.getColorDisplay = function () {
        return this.colorDisplay;
    };
    return ColorDisplay;
}());
exports["default"] = ColorDisplay;
